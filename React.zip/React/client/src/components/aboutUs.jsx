import React from 'react'
import Navbar2 from './navbar2'

const About = () => {
    return (
        <div>
            <Navbar2/>
            <div className="wrapper_about">
                <h3>О нашем приложении</h3>
                <p>
                             
   
  <span id="about_title">1 Жалобы .</span><br/>
    Теперь пожаловаться на нарушение
       законодательство можно онлайн.
       И решить её без лишних слов!) <br/><br/>

  <span id="about_title">2 Валантеры.</span><br/>
     Сообщить Волантерам о помощи на примую.<br/><br/>
       
   <span id="about_title">3 Улучшить город.</span><br/>
       Сообщить о проблемах города для её улучшения.<br/><br/>

  <sapn id="about_title">4 Узнать свой рейтинг города.</sapn><br/>
       Определите насколько комфортно семье,
        пенсионеру или туристу жить в том или 
        ином месте города .
                </p><br/><br/><br/>
                <p id="about_title">
                    Авторы<br/>
                   1) <span id="about_title">Ali Nurlibekov</span><br/>
                   2) <span>Negmatov Zarshed</span>
                </p>
            </div>
        </div>
    )
}

export default About