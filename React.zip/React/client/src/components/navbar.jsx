import React from 'react'
import {  } from 'react-router-dom'

const Navbar = () => {
  return (
    <div className="navbar">
      <div className="logo">
          <div className="line"></div>
            <p>РеWала</p>
          <div className="line"></div>
      </div>
    </div>
  )
}

export default Navbar
